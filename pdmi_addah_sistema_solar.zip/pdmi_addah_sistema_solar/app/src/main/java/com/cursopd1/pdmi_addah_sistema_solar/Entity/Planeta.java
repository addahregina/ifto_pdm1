package com.cursopd1.pdmi_addah_sistema_solar.Entity;
import android.widget.ImageView;

public class Planeta {
    private String nome;

    public Planeta(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
