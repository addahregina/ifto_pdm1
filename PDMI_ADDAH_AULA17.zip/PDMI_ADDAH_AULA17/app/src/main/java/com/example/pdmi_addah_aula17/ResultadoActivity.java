package com.example.pdmi_addah_aula17;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.os.Bundle;
import android.widget.Toast;

public class ResultadoActivity extends AppCompatActivity {
    TextView receiver_msg;
    Button toastbtn;
    Button alertbtn;

    public Context getActivity(){
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        receiver_msg = (TextView) findViewById(R.id.ar_textview_ola);
        toastbtn = findViewById(R.id.ar_btn_toast);
        alertbtn = findViewById(R.id.ar_btn_alert);

        Intent intent = getIntent();
        String ola_msg = "Olá " + intent.getStringExtra("ar_textview_ola_nome") + ", seja bem vindo(a)!";
        receiver_msg.setText(ola_msg);

        toastbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(getApplicationContext(), ola_msg, Toast.LENGTH_LONG);
                toast.show();
            }
        });

        alertbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog dialog = new AlertDialog.Builder(getActivity()).create();
                dialog.setTitle("Alerta");
                dialog.setMessage(ola_msg);
                dialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                dialog.show();
            }
        });
    }

}