package com.example.pdmi_addah_aula17;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText_nome;
    Button enviarbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_nome = (EditText) findViewById(R.id.am_etext_nome);
        enviarbtn = findViewById(R.id.am_btn_enviar);


        enviarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editText_nome.getText().toString();
                Intent intent = new Intent(getApplicationContext(), ResultadoActivity.class);
                intent.putExtra("ar_textview_ola_nome",  nome );
                startActivity(intent);


                //Toast.makeText(getActivity(),"Olá ",Toast.LENGTH_LONG).show();
            }
        });

    }
}