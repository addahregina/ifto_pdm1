package com.cursopd1.pdmi_addah_sistema_solar.Entity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cursopd1.pdmi_addah_sistema_solar.R;

import java.util.List;

public class PlanetaAdapter extends BaseAdapter {
    LayoutInflater inflater;
    List<Planeta> planetas;
    
    public PlanetaAdapter(Context context, List<Planeta> planetas) {
        this.inflater = LayoutInflater.from(context);
        this.planetas = planetas;
    }

    @Override
    public int getCount() {
        return planetas.size();
    }

    @Override
    public Object getItem(int posicao) {
        return planetas.get(posicao);
    }

    @Override
    public long getItemId(int posicao) {
        return posicao;
    }

    @Override
    public View getView(int posicao, View view, ViewGroup parent) {

        Planeta planeta = planetas.get(posicao);
        view = inflater.inflate(R.layout.itens_lista_planetas,null);
        ((TextView)view.findViewById(R.id.textViewNome)).setText(planeta.getNome());

        return view;
    }
    
    
    
   
}
