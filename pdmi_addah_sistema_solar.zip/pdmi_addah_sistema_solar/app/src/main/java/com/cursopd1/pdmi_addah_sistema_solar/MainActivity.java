package com.cursopd1.pdmi_addah_sistema_solar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.cursopd1.pdmi_addah_sistema_solar.Entity.Planeta;
import com.cursopd1.pdmi_addah_sistema_solar.Entity.PlanetaAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView= findViewById(R.id.lsvPlanetas);
        List<Planeta> planetas = new ArrayList<>();

       // ImageView imageView = findViewById(R.id.imageViewFoto);
       // imageView.setImageResource( id );
        Planeta a1 = new Planeta("Vênus");


        planetas.add(a1);

        PlanetaAdapter planetaAdapter = new PlanetaAdapter(this,planetas);
        listView.setAdapter(planetaAdapter);
    }
}