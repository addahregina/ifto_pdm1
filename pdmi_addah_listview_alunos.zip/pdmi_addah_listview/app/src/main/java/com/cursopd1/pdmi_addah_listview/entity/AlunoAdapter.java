package com.cursopd1.pdmi_addah_listview.entity;
import com.cursopd1.pdmi_addah_listview.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class AlunoAdapter extends BaseAdapter {
    LayoutInflater inflater;
    List<Aluno> alunos;

    //construtor
    public AlunoAdapter(Context context, List<Aluno> alunos) {
        this.inflater = LayoutInflater.from(context);
        this.alunos = alunos;
    }

    @Override
    public int getCount() {
        return alunos.size();
    }

    @Override
    public Object getItem(int posicao) {
        return alunos.get(posicao);
    }

    @Override
    public long getItemId(int posicao) {
        return posicao;
    }

    @Override
    public View getView(int posicao, View view, ViewGroup parent) {

        //identifica o item(objeto aluno) da lista através do "posicao"
        Aluno aluno = alunos.get(posicao);
        //infla o layout "itens_lista_customizada_aluno" para referênciar/receber o item
        view = inflater.inflate(R.layout.itens_lista_alunos,null);
        //aponta qual dado o componente do layout vai receber
        ((TextView)view.findViewById(R.id.textViewNome)).setText(aluno.getNome());
        ((TextView)view.findViewById(R.id.textViewNota1)).setText(String.valueOf(aluno.getNota1()));
        ((TextView)view.findViewById(R.id.textViewNota2)).setText(String.valueOf(aluno.getNota2()));

        return view;
    }
}
