package com.cursopd1.pdmi_addah_listview.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.cursopd1.pdmi_addah_listview.R;
import com.cursopd1.pdmi_addah_listview.entity.Aluno;
import com.cursopd1.pdmi_addah_listview.entity.AlunoAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView= findViewById(R.id.lsvAlunos);
        List<Aluno> alunos = new ArrayList<>();

        Aluno a1 = new Aluno("Aluno 1",9.5,6.8);
        Aluno a2 = new Aluno("Aluno 2",8.5,6.8);
        Aluno a3 = new Aluno("Aluno 3",7.5,8.8);
        Aluno a4 = new Aluno("Aluno 4",6.5,7.8);

        //add alunos na lista

        alunos.add(a1);
        alunos.add(a2);
        alunos.add(a3);
        alunos.add(a4);

        AlunoAdapter alunoAdapter = new AlunoAdapter(this,alunos);
        listView.setAdapter(alunoAdapter);

        /*List<String> alunos = new ArrayList();
        alunos.add("aluno 1");
        alunos.add("aluno 2");
        //...
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, alunos);
        listViewAlunos.setAdapter(adapter);
           */
    }
}